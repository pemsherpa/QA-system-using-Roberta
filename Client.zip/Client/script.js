function getAnswer() {
    const question = document.getElementById('question').value;
    const context = document.getElementById('context').value;

    fetch('/answer', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ question: question, context: context })
    })
    .then(response => response.json())
    .then(data => {
        const responseDiv = document.getElementById('response');
        if (data.answer) {
            responseDiv.innerHTML = `<strong>Answer:</strong> ${data.answer}`;
        } else {
            responseDiv.innerHTML = `<strong>Error:</strong> ${data.error}`;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        const responseDiv = document.getElementById('response');
        responseDiv.innerHTML = `<strong>Error:</strong> ${error.message}`;
    });
}